import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class RockPaperScissorsFrame extends JFrame
{
    private final JButton rockButton;
    private final JButton paperButton;
    private final JButton scissorsButton;
    private final JButton quitButton;
    private final JTextArea resultsTextArea;
    private final JTextField playerWinsField;
    private final JTextField computerWinsField;
    private final JTextField tiesField;

    private int playerWins;
    private int computerWins;
    private int ties;

    public RockPaperScissorsFrame()
    {
        setTitle("Rock Paper Scissors Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel buttonsPanel = new JPanel(new GridLayout(1, 4));
        rockButton = createButton("Rock", "rock.jpg");
        paperButton = createButton("Paper", "paper.png");
        scissorsButton = createButton("Scissors", "scissor.jpg");
        quitButton = createButton("Quit", null);
        buttonsPanel.add(rockButton);
        buttonsPanel.add(paperButton);
        buttonsPanel.add(scissorsButton);
        buttonsPanel.add(quitButton);
        buttonsPanel.setBorder(BorderFactory.createTitledBorder("Options"));

        JPanel statsPanel = new JPanel(new GridLayout(3, 2));
        statsPanel.setBorder(BorderFactory.createTitledBorder("Stats"));
        statsPanel.add(new JLabel("Player Wins:"));
        playerWinsField = new JTextField(5);
        playerWinsField.setEditable(false);
        statsPanel.add(playerWinsField);
        statsPanel.add(new JLabel("Computer Wins:"));
        computerWinsField = new JTextField(5);
        computerWinsField.setEditable(false);
        statsPanel.add(computerWinsField);
        statsPanel.add(new JLabel("Ties:"));
        tiesField = new JTextField(5);
        tiesField.setEditable(false);
        statsPanel.add(tiesField);

        resultsTextArea = new JTextArea(10, 20);
        resultsTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultsTextArea);

        add(buttonsPanel, BorderLayout.NORTH);
        add(statsPanel, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);

        playerWins = 0;
        computerWins = 0;
        ties = 0;

        updateStats();

        rockButton.addActionListener(e -> playGame("Rock"));
        paperButton.addActionListener(e -> playGame("Paper"));
        scissorsButton.addActionListener(e -> playGame("Scissors"));
        quitButton.addActionListener(e -> System.exit(0));
    }

    private JButton createButton(String label, String imageName)
    {
        JButton button;
        if (imageName != null)
        {
            ImageIcon icon = new ImageIcon(getClass().getResource(imageName));
            button = new JButton(label, icon);
        } else
        {
            button = new JButton(label);
        }
        return button;
    }

    private void playGame(String playerChoice)
    {
        String[] choices = {"Rock", "Paper", "Scissors"};
        Random random = new Random();
        int computerIndex = random.nextInt(3);
        String computerChoice = choices[computerIndex];

        String result;
        if (playerChoice.equals(computerChoice))
        {
            result = "Tie";
            ties++;
        } else if ((playerChoice.equals("Rock") && computerChoice.equals("Scissors")) ||
                (playerChoice.equals("Paper") && computerChoice.equals("Rock")) ||
                (playerChoice.equals("Scissors") && computerChoice.equals("Paper")))
        {
            result = "Player wins";
            playerWins++;
        } else
        {
            result = "Computer wins";
            computerWins++;
        }
        updateStats();
        displayResult(playerChoice, computerChoice, result);
    }

    private void updateStats()
    {
        playerWinsField.setText(String.valueOf(playerWins));
        computerWinsField.setText(String.valueOf(computerWins));
        tiesField.setText(String.valueOf(ties));
    }

    private void displayResult(String playerChoice, String computerChoice, String result)
    {
        String output = playerChoice + " vs " + computerChoice + " - " + result;
        resultsTextArea.append(output + "\n");
    }
}
